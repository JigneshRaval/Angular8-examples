module.exports = {
  auth: require('./auth'),
  users: require('./users'),
  projects: require('./projects'),
  tasks: require('./tasks')
};
