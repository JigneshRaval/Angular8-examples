import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboardsystem',
  templateUrl: './dashboardsystem.component.html',
  styleUrls: ['./dashboardsystem.component.css']
})
export class DashboardsystemComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
