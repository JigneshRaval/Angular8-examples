var webpack = require('webpack');
var HtmlWebpackPlugin = require('html-webpack-plugin');
var AddAssetHtmlPlugin = require('add-asset-html-webpack-plugin');
var helpers = require('./helpers');

module.exports = {
  entry: [
    './config/polyfills.ts',
    './src2/main.ts'
  ],

  output: {
    path: helpers.root('dist'),
    publicPath: 'http://localhost:8080/',
    filename: 'bundle2.js'
  },

  resolve: {
    // resolve module file requests by looking for explicit extensions
    // or look for matching files with .js or .ts extensions
    extensions: ['*', '.js', '.ts']
  },

  module: {
    loaders: [
      {
        test: /\.ts$/,
        loaders: ['awesome-typescript-loader', '@angularclass/hmr-loader', 'angular2-template-loader']
      },
      {
        test: /\.html$/,
        loader: 'raw-loader'
      },
      // handle component-scoped styles specified with styleUrls
      {
        test: /\.css$/,
        include: helpers.root('src2'),
        loader: 'raw-loader'
      }
    ]
  },

  plugins: [
    new webpack.DllReferencePlugin({
      context: '.',
      manifest: require(helpers.root('dist', 'vendor-manifest.json'))
    }),
    new webpack.DllReferencePlugin({
      context: '.',
      manifest: require(helpers.root('dist', 'polyfills-manifest.json'))
    }),
    new HtmlWebpackPlugin({
      template: 'src2/index.html',
      filename: 'dist/index2.html'
    }),
    new AddAssetHtmlPlugin([
      { filepath: 'dist/polyfills.dll.js', includeSourcemap: false },
      { filepath: 'dist/vendor.dll.js', includeSourcemap: false },
      { filepath: 'dist/bundle.js', includeSourcemap: false }
    ])
  ],

  devServer: {
    host: '0.0.0.0',
    port: 8080
  }
};
