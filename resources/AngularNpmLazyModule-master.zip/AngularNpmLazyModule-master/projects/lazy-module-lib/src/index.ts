export * from './lib/lazy-module-lib.module';
