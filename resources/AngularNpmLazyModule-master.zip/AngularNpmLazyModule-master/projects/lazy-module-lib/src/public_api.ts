/*
 * Public API Surface of lazy-module-lib
 */

export * from './lib/lazy-module-lib.service';
export * from './lib/lazy-module-lib.component';
export * from './lib/lazy-module-lib.module';
