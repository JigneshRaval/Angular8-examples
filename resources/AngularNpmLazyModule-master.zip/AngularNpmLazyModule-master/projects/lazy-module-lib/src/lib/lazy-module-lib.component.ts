import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-lazy-module-lib',
  templateUrl: './lazy-module-lib.component.html',
  styles: []
})
export class LazyModuleLibComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
